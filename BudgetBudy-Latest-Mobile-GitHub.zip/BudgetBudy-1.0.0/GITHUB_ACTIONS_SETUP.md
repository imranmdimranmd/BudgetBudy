# BudgetBudy - GitHub Actions APK Build

## Build environment

- Flutter: 3.24.5
- Dart: 3.5.x (bundled with Flutter 3.24.5)
- Java: 17
- Android Gradle Plugin: 8.1.1
- Gradle: 8.2
- Kotlin: 1.8.22
- compileSdk: 34
- targetSdk: 34

## GitHub steps

1. Create a private GitHub repository.
2. Upload the contents of this project so `pubspec.yaml` is at repository root.
3. Commit and push to `main`.
4. Open **Actions** in GitHub.
5. Select **Build BudgetBudy Android APK**.
6. Choose **Run workflow** for a manual build, or push to `main` to trigger it automatically.
7. Open the successful workflow run.
8. Under **Artifacts**, download `BudgetBudy-release`.
9. Extract the ZIP and install `BudgetBudy-release.apk` on Android.

## First build

The workflow intentionally keeps `flutter analyze` non-blocking on the first build. Once the project builds successfully, remove `continue-on-error: true` from that step to make analysis errors fail CI.
